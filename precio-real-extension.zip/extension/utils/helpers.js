// Content scripts no son módulos ES; exponemos en namespace global para evitar colisiones.
(function () {
  'use strict';

  const ns = (window.PrecioReal = window.PrecioReal || {});

  // ── Logger condicional ────────────────────────────────────────────────────
  // Activado por:
  //   • Query param `?precio_real_debug=1` (sticky en sessionStorage)
  //   • localStorage.precioRealDebug = '1'
  //   • localStorage.precioRealDebug = '<retailer>' (filtra solo ese retailer)
  // Nada de logs en producción a menos que el dev/usuario los pida explícitamente.
  function readDebugFlag() {
    try {
      const params = new URLSearchParams(location.search);
      const q = params.get('precio_real_debug');
      if (q === '1' || q === 'true') {
        try { sessionStorage.setItem('precioRealDebug', '1'); } catch (_) {}
        return '1';
      }
      const ss = (function () {
        try { return sessionStorage.getItem('precioRealDebug'); } catch (_) { return null; }
      })();
      if (ss) return ss;
      const ls = (function () {
        try { return localStorage.getItem('precioRealDebug'); } catch (_) { return null; }
      })();
      return ls;
    } catch (_) { return null; }
  }
  const DEBUG_FLAG = readDebugFlag();
  const DEBUG = !!DEBUG_FLAG;
  function debugMatches(siteKey) {
    if (!DEBUG) return false;
    if (DEBUG_FLAG === '1' || DEBUG_FLAG === 'true' || DEBUG_FLAG === '*') return true;
    if (!siteKey) return true;
    return DEBUG_FLAG === siteKey;
  }
  const log = {
    debug(siteKey, ...args) {
      if (debugMatches(siteKey)) {
        try { console.log('[Precio Real][debug]', siteKey || '-', ...args); } catch (_) {}
      }
    },
    info(...args) { try { console.info('[Precio Real]', ...args); } catch (_) {} },
    warn(...args) { try { console.warn('[Precio Real]', ...args); } catch (_) {} },
  };

  const SUPPORTED_SITES = [
    'mercadolibre',
    'fravega',
    'garbarino',
    'falabella',
    'carrefour',
    'coto',
    'naldo',
    'musimundo',
    'cetrogar',
    'megatone',
    'dia',
    'jumbo',
    'disco',
    'sodimac',
    'easy',
    'hendel',
    'rodo',
    'ribeiro',
    'compumundo',
    'samsung',
    // Ciclo 14: marcas con tienda oficial argentina (electrónicos / electrodomésticos)
    // que aparecen en Hot Sale 2026 con campañas propias.
    'lg',
    'sony',
    'philips',
    'bgh',
    'noblex',
    'whirlpool',
    // Ciclo 1582: nuevos retailers Hot Sale AR.
    'changomas',
    'electrolux',
    'drean',
    'motorola',
    'todomodo',
    // Ciclo 1584: Amazon AR + HiperTehno.
    'amazon',
    'hipertehno',
    // Ciclo 1599: Xiaomi Store AR, Philco AR, Venex (gaming/PC).
    'xiaomi',
    'philco',
    'venex',
    // Ciclo 1594: Bgood (electrónica), HP Tienda AR, Lenovo Store AR,
    // Alphatec (PrestaShop), EXO AR (notebooks/PCs WooCommerce).
    'bgood',
    'hptienda',
    'lenovo',
    'alphatec',
    'exo',
    // Ciclo 1596: Hisense AR (VTEX), TCL AR (Shopify), Pycca (Magento 2).
    'hisense',
    'tcl',
    'pycca',
    // Ciclo 1613: Newsan (VTEX appliances), Asus Store AR (Next.js), Mac Center (WooCommerce).
    'newsan',
    'asus',
    'maccenter',
    // Ciclo 1603: Full (WooCommerce), Micro Center AR (Magento 2), iPoint AR (Shopify).
    'full',
    'microcenter',
    'ipoint',
    // Ciclo 1606: Acer Store AR (Magento 2), Coolbox AR (Shopify gaming),
    // Olimpo AR (WooCommerce electrónica).
    'acer',
    'coolbox',
    'olimpo',
    // Ciclo 1607: Dexter AR (Shopify deportes), TGC AR (Magento 2 gaming),
    // Maxiconsumo AR (VTEX supermercado mayorista).
    'dexter',
    'tgc',
    'maxiconsumo',
    // Ciclo 1608: FullH4rd AR (Shopify gaming/periféricos), StartTech AR (Magento 2
    // gaming/PC), PC House AR (WooCommerce hardware).
    'fullh4rd',
    'starttech',
    'pchouse',
    // Ciclo 1609: MaxiHogar (VTEX), PC Factory (Magento 2), CompraGamer (custom),
    // Golden Shop (Shopify), Soluciones (WooCommerce).
    'maxihogar',
    'pcfactory',
    'compragamer',
    'goldenshop',
    'soluciones',
    // Ciclo 1610: Zetta AR (WooCommerce electrónica), Geek Store AR (Shopify gaming),
    // Computodo AR (Magento 2 hardware/PC).
    'zetta',
    'geekstore',
    'computodo',
    // Ciclo 1612: Arredondo (PrestaShop electrónica), iThink (Shopify Apple reseller),
    // Nexstore (Magento 2 gaming/PC), Cable Hogar (WooCommerce electrónica).
    'arredondo',
    'ithink',
    'nexstore',
    'cablehogar',
    // Ciclo 1614: Bit (Shopify gaming/hardware), Digital Haus (WooCommerce electrónica),
    // InStore (Magento 2 audio/video hifi), Staples AR (WooCommerce oficina),
    // Gotta (WooCommerce gaming/periféricos).
    'bit',
    'digitalhaus',
    'instore',
    'staples',
    'gotta',
    // Ciclo 1615: Powerplanet (WooCommerce gaming/periféricos), I-Gaming Store (Shopify
    // gaming/hardware), Netizar (Magento 2 hardware/networking), Megastore AR
    // (WooCommerce electrónica), Centurytech (Magento 2 hardware/PC).
    'powerplanet',
    'igaming',
    'netizar',
    'megastore',
    'centurytech',
    // Ciclo 1616: Klibr (Shopify gaming/periféricos), Lazer (Shopify gaming sillas/periféricos),
    // PcArg (WooCommerce componentes/hardware/gaming AR).
    'klibr',
    'lazer',
    'pcarg',
    // Ciclo 1617: GearZone AR (Shopify gaming bundles/periféricos), Binario AR (WooCommerce
    // componentes/hardware gaming), CompuPC AR (WooCommerce hardware/PC armado).
    'gearzone',
    'binario',
    'compupc',
    // Ciclo 1618: retailers agregados a retailers.js/manifest en ciclo previo pero faltaban en helpers.
    // Carsa (WooCommerce electrodomésticos regional), GrupoDIN (Magento 2 electrónica),
    // Coppel AR (VTEX IO línea blanca/electrónica), Megatronics AR (Magento 2 gaming/IT),
    // Mac Station (Shopify Apple Premium Reseller), Winpy AR (Next.js electrónica/gaming).
    'carsa',
    'grupodin',
    'coppel',
    'megatronics',
    'macstation',
    'winpy',
    // Ciclo 1618: nuevos retailers Hot Sale AR. Autronic (WooCommerce electrónica/electrodomésticos
    // regional), Megatrix (Shopify gaming/periféricos), Pixelstore (Shopify Apple reseller AR).
    'autronic',
    'megatrix',
    'pixelstore',
    // Ciclo 1623: Farmacity (WooCommerce health/beauty), Ripley AR (SAP Commerce department
    // store), PC Box AR (WooCommerce gaming/hardware), Oster AR (VTEX electrodomésticos),
    // Garmin Store AR (SPA custom wearables/GPS — manifest restringe a /es-AR/ paths).
    'farmacity',
    'ripley',
    'pcbox',
    'oster',
    'garmin',
  ];

  function detectSite(hostname) {
    if (!hostname || typeof hostname !== 'string') return null;
    const h = hostname.toLowerCase();
    if (h.endsWith('mercadolibre.com.ar')) return 'mercadolibre';
    if (h.endsWith('fravega.com')) return 'fravega';
    if (h.endsWith('garbarino.com')) return 'garbarino';
    if (h.endsWith('falabella.com.ar')) return 'falabella';
    if (h.endsWith('carrefour.com.ar')) return 'carrefour';
    if (h.endsWith('cotodigital3.com.ar')) return 'coto';
    // coto.com.ar es el dominio principal actual de Coto (antes cotodigital3).
    // El manifest cubre ambos; helpers mapea ambos al mismo siteKey.
    if (h.endsWith('coto.com.ar')) return 'coto';
    if (h.endsWith('naldo.com.ar')) return 'naldo';
    if (h.endsWith('musimundo.com')) return 'musimundo';
    if (h.endsWith('cetrogar.com.ar')) return 'cetrogar';
    if (h.endsWith('megatone.net')) return 'megatone';
    if (h.endsWith('diaonline.supermercadosdia.com.ar')) return 'dia';
    if (h.endsWith('jumbo.com.ar')) return 'jumbo';
    if (h.endsWith('disco.com.ar')) return 'disco';
    if (h.endsWith('sodimac.com.ar')) return 'sodimac';
    if (h.endsWith('easy.com.ar')) return 'easy';
    if (h.endsWith('hendel.com.ar')) return 'hendel';
    if (h.endsWith('rodo.com.ar')) return 'rodo';
    if (h.endsWith('ribeiro.com.ar')) return 'ribeiro';
    if (h.endsWith('compumundo.com.ar')) return 'compumundo';
    // Samsung opera shop.samsung.com.ar (Hybris) y, ocasionalmente, samsung.com/ar.
    // Solo nos interesa el e-commerce AR, no la home global.
    if (h.endsWith('samsung.com.ar')) return 'samsung';
    // Ciclo 14: marcas con tiendas oficiales AR. LG opera lg.com con subdominios
    // por país; el manifest matchea solo las rutas /ar/. Sony usa sony.com.ar
    // (e-commerce propio). Philips, BGH, Noblex, Whirlpool tienen TLD .com.ar
    // dedicado para AR.
    if (h.endsWith('lg.com')) return 'lg';
    if (h.endsWith('sony.com.ar')) return 'sony';
    if (h.endsWith('philips.com.ar')) return 'philips';
    if (h.endsWith('bgh.com.ar')) return 'bgh';
    if (h.endsWith('noblex.com.ar')) return 'noblex';
    if (h.endsWith('whirlpool.com.ar')) return 'whirlpool';
    // Ciclo 1582: nuevos retailers Hot Sale AR.
    if (h.endsWith('changomas.com.ar')) return 'changomas';
    if (h.endsWith('electrolux.com.ar')) return 'electrolux';
    if (h.endsWith('drean.com.ar')) return 'drean';
    if (h.endsWith('motorola.com.ar')) return 'motorola';
    if (h.endsWith('todomodo.com.ar')) return 'todomodo';
    // Ciclo 1584: Amazon AR lanzó amazon.com.ar en 2022. HiperTehno es cadena
    // de electrónica con presencia fuerte en Hot Sale.
    if (h.endsWith('amazon.com.ar')) return 'amazon';
    if (h.endsWith('hipertehno.com.ar')) return 'hipertehno';
    // Ciclo 1599: Xiaomi Store AR (tienda.mi.com/ar), Philco AR (VTEX),
    // Venex (Magento 2, gaming/PC components).
    if (h.endsWith('tienda.mi.com')) return 'xiaomi';
    if (h.endsWith('philco.com.ar')) return 'philco';
    if (h.endsWith('venex.com.ar')) return 'venex';
    // Ciclo 1594: Bgood, HP Tienda AR, Lenovo Store AR, Alphatec, EXO AR.
    // Lenovo opera lenovo.com con subdominios por país; el manifest matchea solo /ar/.
    // HP Tienda opera hptienda.com.ar (e-commerce propio separado de hp.com).
    if (h.endsWith('bgood.com.ar')) return 'bgood';
    if (h.endsWith('hptienda.com.ar')) return 'hptienda';
    if (h.endsWith('lenovo.com')) return 'lenovo';
    if (h.endsWith('alphatec.com.ar')) return 'alphatec';
    if (h.endsWith('exo.com.ar')) return 'exo';
    // Ciclo 1596: Hisense AR (VTEX), TCL AR (Shopify), Pycca (Magento 2).
    if (h.endsWith('hisense.com.ar')) return 'hisense';
    if (h.endsWith('tcl.com.ar')) return 'tcl';
    if (h.endsWith('pycca.com.ar')) return 'pycca';
    // Ciclo 1613: Newsan (VTEX), Asus Store AR (store.asus.com/ar/), Mac Center (WooCommerce).
    // Asus usa store.asus.com como hostname; el manifest restringe a /ar/* paths.
    if (h.endsWith('newsan.com.ar')) return 'newsan';
    if (h === 'store.asus.com') return 'asus';
    if (h.endsWith('maccenter.com.ar')) return 'maccenter';
    // Ciclo 1603: Full (WooCommerce), Micro Center AR (Magento 2), iPoint AR (Shopify).
    if (h.endsWith('full.com.ar')) return 'full';
    if (h.endsWith('microcenter.com.ar')) return 'microcenter';
    if (h.endsWith('ipoint.com.ar')) return 'ipoint';
    // Ciclo 1606: Acer Store AR (store.acer.com/es-ar/), Coolbox AR (Shopify gaming),
    // Olimpo AR (WooCommerce electrónica). Acer usa el subdominio store.acer.com
    // con locale /es-ar/; el manifest restringe a ese path. Coolbox y Olimpo son
    // retailers .com.ar dedicados al mercado argentino.
    if (h === 'store.acer.com') return 'acer';
    if (h.endsWith('coolbox.com.ar')) return 'coolbox';
    if (h.endsWith('olimpo.com.ar')) return 'olimpo';
    // Ciclo 1607: Dexter AR (Shopify deportes), TGC AR (Magento 2 gaming),
    // Maxiconsumo AR (VTEX supermercado mayorista).
    if (h.endsWith('dexter.com.ar')) return 'dexter';
    if (h.endsWith('tgc.com.ar')) return 'tgc';
    if (h.endsWith('maxiconsumo.com')) return 'maxiconsumo';
    // Ciclo 1608: FullH4rd AR (Shopify gaming/periféricos), StartTech AR (Magento 2
    // gaming/PC), PC House AR (WooCommerce hardware).
    if (h.endsWith('fullh4rd.com.ar')) return 'fullh4rd';
    if (h.endsWith('startechpc.com.ar')) return 'starttech';
    if (h.endsWith('phouse.com.ar')) return 'pchouse';
    // Ciclo 1609: MaxiHogar (VTEX), PC Factory (Magento 2), CompraGamer (custom),
    // Golden Shop (Shopify), Soluciones (WooCommerce).
    if (h.endsWith('maxihogar.com.ar')) return 'maxihogar';
    if (h.endsWith('pcfactory.com.ar')) return 'pcfactory';
    if (h.endsWith('compragamer.com')) return 'compragamer';
    if (h.endsWith('goldenshop.com.ar')) return 'goldenshop';
    if (h.endsWith('soluciones.com.ar')) return 'soluciones';
    // Ciclo 1610: Zetta AR (WooCommerce), Geek Store AR (Shopify), Computodo AR (Magento 2).
    if (h.endsWith('zetta.net.ar')) return 'zetta';
    if (h.endsWith('geekstore.com.ar')) return 'geekstore';
    if (h.endsWith('computodo.com.ar')) return 'computodo';
    // Ciclo 1612: Arredondo (PrestaShop electrónica), iThink (Shopify Apple reseller),
    // Nexstore (Magento 2 gaming/PC), Cable Hogar (WooCommerce electrónica).
    if (h.endsWith('arredondo.com.ar')) return 'arredondo';
    if (h.endsWith('ithink.com.ar')) return 'ithink';
    if (h.endsWith('nexstore.com.ar')) return 'nexstore';
    if (h.endsWith('cablehogar.com.ar')) return 'cablehogar';
    // Ciclo 1614: Bit (Shopify gaming/hardware), Digital Haus (WooCommerce electrónica),
    // InStore (Magento 2 audio/video hifi), Staples AR (WooCommerce oficina),
    // Gotta (WooCommerce gaming/periféricos).
    if (h.endsWith('bit.ar')) return 'bit';
    if (h.endsWith('digitalhaus.com.ar')) return 'digitalhaus';
    if (h.endsWith('instore.com.ar')) return 'instore';
    if (h.endsWith('staples.com.ar')) return 'staples';
    if (h.endsWith('gotta.com.ar')) return 'gotta';
    // Ciclo 1615: Powerplanet (WooCommerce gaming/periféricos), I-Gaming Store (Shopify
    // gaming/hardware), Netizar (Magento 2 hardware/networking), Megastore AR
    // (WooCommerce electrónica), Centurytech (Magento 2 hardware/PC).
    if (h.endsWith('powerplanet.com.ar')) return 'powerplanet';
    if (h.endsWith('igamingstore.com.ar')) return 'igaming';
    if (h.endsWith('netizar.com.ar')) return 'netizar';
    if (h.endsWith('megastore.com.ar')) return 'megastore';
    if (h.endsWith('centurytech.com.ar')) return 'centurytech';
    // Ciclo 1616: Klibr (Shopify gaming/periféricos), Lazer (Shopify gaming sillas/periféricos),
    // PcArg (WooCommerce componentes/hardware/gaming AR).
    if (h.endsWith('klibr.com.ar')) return 'klibr';
    if (h.endsWith('lazer.com.ar')) return 'lazer';
    if (h.endsWith('pcarg.com.ar')) return 'pcarg';
    // Ciclo 1617: GearZone AR (Shopify gaming bundles/periféricos — referenciado en comentarios
    // de data-bundle-id desde ciclo 1616), Binario AR (WooCommerce), CompuPC AR (WooCommerce).
    if (h.endsWith('gearzone.com.ar')) return 'gearzone';
    if (h.endsWith('binario.com.ar')) return 'binario';
    if (h.endsWith('compupc.com.ar')) return 'compupc';
    // Ciclo 1618: fix retailers que tenían entrada en retailers.js/manifest pero no en helpers.
    if (h.endsWith('carsa.com.ar')) return 'carsa';
    if (h.endsWith('grupodin.com')) return 'grupodin';
    if (h.endsWith('coppel.com')) return 'coppel';
    if (h.endsWith('megatronics.com.ar')) return 'megatronics';
    if (h.endsWith('macstation.com.ar')) return 'macstation';
    if (h.endsWith('winpy.com.ar')) return 'winpy';
    // Ciclo 1618: nuevos retailers.
    if (h.endsWith('autronic.com.ar')) return 'autronic';
    if (h.endsWith('megatrix.com.ar')) return 'megatrix';
    if (h.endsWith('pixelstore.com.ar')) return 'pixelstore';
    // Ciclo 1623: Farmacity, Ripley AR, PC Box AR, Oster AR, Garmin AR.
    // Garmin usa garmin.com global; el manifest restringe la carga a /es-AR/* paths.
    if (h.endsWith('farmacity.com')) return 'farmacity';
    if (h.endsWith('ripley.com.ar')) return 'ripley';
    if (h.endsWith('pcbox.com.ar')) return 'pcbox';
    if (h.endsWith('oster.com.ar')) return 'oster';
    if (h.endsWith('garmin.com')) return 'garmin';
    return null;
  }

  // Acepta múltiples formatos:
  //   "$ 1.234.567,89" (AR) → 1234567.89
  //   "1,234,567.89"   (US) → 1234567.89
  //   "1234.56"        (schema.org / meta itemprop="price") → 1234.56
  //   "1234,56"        (AR sin separador de miles) → 1234.56
  // Heurística: si aparecen los dos separadores, el último es el decimal.
  // Si aparece uno solo, es decimal sólo si quedan 1–2 dígitos detrás.
  // Si rawString viene de un meta/attribute (forceUSDecimal=true), forzamos
  // formato US porque schema.org lo exige así.
  function normalizePrice(rawString, opts) {
    if (rawString == null) return null;
    const forceUSDecimal = !!(opts && opts.forceUSDecimal);
    const s = String(rawString).trim();
    if (!s) return null;
    let cleaned = s.replace(/[^\d.,-]/g, '');
    if (!cleaned || cleaned === '-' || cleaned === '.' || cleaned === ',') return null;

    if (forceUSDecimal) {
      // Formato schema.org: "1234.56" o "1,234.56" — coma siempre miles.
      cleaned = cleaned.replace(/,/g, '');
    } else {
      const hasDot = cleaned.includes('.');
      const hasComma = cleaned.includes(',');
      if (hasDot && hasComma) {
        // El separador más a la derecha es el decimal.
        const lastDot = cleaned.lastIndexOf('.');
        const lastComma = cleaned.lastIndexOf(',');
        if (lastComma > lastDot) {
          // AR clásico: "1.234.567,89"
          cleaned = cleaned.replace(/\./g, '').replace(',', '.');
        } else {
          // US clásico: "1,234,567.89"
          cleaned = cleaned.replace(/,/g, '');
        }
      } else if (hasComma) {
        // Sólo coma: decimal si quedan 1–2 dígitos detrás, miles si más.
        const after = cleaned.length - cleaned.lastIndexOf(',') - 1;
        if (after === 1 || after === 2) {
          cleaned = cleaned.replace(',', '.');
        } else {
          cleaned = cleaned.replace(/,/g, '');
        }
      } else if (hasDot) {
        // Sólo punto: decimal si quedan 1–2 dígitos detrás, miles si más.
        const after = cleaned.length - cleaned.lastIndexOf('.') - 1;
        if (after === 1 || after === 2) {
          // ya está bien
        } else {
          cleaned = cleaned.replace(/\./g, '');
        }
      }
    }

    if (!cleaned || cleaned === '-' || cleaned === '.') return null;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : null;
  }

  // Selectores por retailer viven en utils/retailers.js (issue #6).
  // Fallback inline para defensa en profundidad si retailers.js no cargó.
  const RETAILERS = (ns && ns.RETAILERS) || {};
  const PRICE_SELECTORS = Object.fromEntries(
    Object.entries(RETAILERS).map(([k, cfg]) => [k, cfg.selectors || []])
  );

  // Ciclo 1619: agregamos og:price:amount y product:price:amount como fallbacks
  // genéricos. Estos meta Open Graph son emitidos por la mayoría de plataformas
  // (Shopify, WooCommerce, Magento, PrestaShop) incluso cuando el retailer no
  // tiene un selector específico en retailers.js. Colocamos los meta primero porque
  // son más confiables (formato US schema.org, valor limpio sin decoración) y
  // evitan falsos positivos de precios tachados o cuotas que pueden estar dentro
  // de un elemento .price en retailers no mapeados.
  const GENERIC_PRICE_SELECTORS = (ns && ns.GENERIC_PRICE_SELECTORS) || [
    'meta[itemprop="price"]',
    'meta[property="og:price:amount"]',
    'meta[property="product:price:amount"]',
    '[itemprop="price"]',
    '.price',
    '.product-price',
    '[data-testid*="price" i]',
  ];

  // Devuelve { raw, fromAttribute }. fromAttribute=true significa que el valor
  // viene de un atributo (meta content / data-* / itemprop content) y por lo
  // tanto debe parsearse como formato US (schema.org).
  function readPriceFromElement(el) {
    if (!el) return { raw: null, fromAttribute: false };
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'meta') {
      return { raw: el.getAttribute('content'), fromAttribute: true };
    }
    if (el.getAttribute && el.getAttribute('itemprop') === 'price') {
      const c = el.getAttribute('content');
      if (c) return { raw: c, fromAttribute: true };
      return { raw: el.textContent, fromAttribute: false };
    }
    // Algunos retailers exponen el precio como data-price="1234.56" en formato US.
    // Falabella/Sodimac usan data-internet-price, data-cmr-price, data-event-price.
    // Megatone/legacy stores usan data-price-amount.
    if (el.dataset) {
      const dp = el.dataset.price
        || el.dataset.value
        || el.dataset.amount
        || el.dataset.internetPrice   // Falabella / Sodimac
        || el.dataset.cmrPrice        // Falabella / Sodimac (tarjeta CMR)
        || el.dataset.eventPrice      // Falabella / Sodimac
        || el.dataset.priceAmount     // Magento 2 (Cetrogar, Rodo, Noblex)
        // Ciclo 1604: atributos adicionales observados en nuevos retailers.
        || el.dataset.specialPrice    // Magento 2 precio de oferta (sale price real)
        || el.dataset.fsPrice         // VTEX Faststore (data-fs-price)
        || el.dataset.sellingPrice    // Shopify apps custom (data-selling-price)
        // Ciclo 1607: atributos adicionales observados en nuevos retailers.
        || el.dataset.fsPriceValue    // VTEX Faststore v2+ (data-fs-price-value)
        || el.dataset.priceValue      // Shopify custom themes (data-price-value, en centavos: dividir por 100)
        || el.dataset.comparePrice    // Shopify compare-at price (NO usar — es precio anterior)
        || el.dataset.productPrice    // WooCommerce custom (data-product-price)
        || el.dataset.salePrice;      // WooCommerce / Magento generic (data-sale-price)
      // Shopify expone data-price-value en centavos (integer: 12345 = $123.45).
      // Si el valor viene de dataset.priceValue, dividir por 100 antes de devolver.
      if (dp) {
        // Detectar si es Shopify data-price-value (siempre entero en centavos).
        // Heurística: si el atributo que matcheó es priceValue y el valor parece entero
        // > 1000 (sin separador decimal), asumimos que está en centavos.
        if (el.dataset.priceValue && dp === el.dataset.priceValue) {
          const asInt = parseInt(dp, 10);
          if (!isNaN(asInt) && asInt > 0 && String(asInt) === dp.trim()) {
            // Valor entero en centavos: devolver como string dividido por 100.
            return { raw: String(asInt / 100), fromAttribute: true };
          }
        }
        // Ciclo 1610: data-price en Shopify también puede ser centavos enteros
        // (integer sin separador decimal, ej. "1234500" = $12.345,00). Algunos
        // temas Shopify (Geek Store AR, Coolbox AR, temas custom gaming) usan
        // data-price en lugar de data-price-value para el mismo patrón. Si el
        // valor es un integer puro > 100 y proviene de dataset.price, dividimos por 100.
        if (el.dataset.price && dp === el.dataset.price) {
          const raw = dp.trim();
          const asInt = parseInt(raw, 10);
          if (!isNaN(asInt) && asInt > 100 && String(asInt) === raw && !raw.includes('.') && !raw.includes(',')) {
            return { raw: String(asInt / 100), fromAttribute: true };
          }
        }
        return { raw: dp, fromAttribute: true };
      }
    }
    return { raw: el.textContent, fromAttribute: false };
  }

  function tryLdJsonPrice() {
    try {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const s of scripts) {
        let parsed;
        try {
          parsed = JSON.parse(s.textContent);
        } catch (e) {
          continue;
        }
        // Algunos retailers (VTEX, Shopify) emiten ld+json envuelto en @graph
        // (un array de nodos hermanos). walkLdJson ya recurse por keys, pero
        // promovemos @graph al toplevel para asegurar el find del Product.
        const root = (parsed && parsed['@graph']) ? parsed['@graph'] : parsed;
        const found = walkLdJson(root);
        if (found != null) {
          const n = Number(found);
          if (Number.isFinite(n) && n > 0) return n;
        }
      }
    } catch (e) {
      // ignore
    }
    return null;
  }

  // Devuelve true si el offer está OutOfStock/Discontinued/SoldOut según
  // schema.org availability. Cualquier otro valor (InStock, PreOrder, ausente)
  // se considera vendible y por lo tanto se acepta su precio.
  function isOfferOutOfStock(offer) {
    if (!offer || typeof offer !== 'object') return false;
    const av = offer.availability;
    if (!av) return false;
    const s = String(av).toLowerCase();
    return /outofstock|discontinued|soldout/.test(s);
  }

  function pickOfferPrice(offer) {
    if (!offer || typeof offer !== 'object') return null;
    if (isOfferOutOfStock(offer)) return null;
    // Preferencia: price > priceSpecification.price > lowPrice. lowPrice/highPrice
    // son del AggregateOffer y suelen ser el rango de listado, no el precio
    // del producto seleccionado en la PDP. Sólo usamos lowPrice como último
    // recurso (cuando no hay price visible).
    if (offer.price != null) return offer.price;
    if (offer.priceSpecification && typeof offer.priceSpecification === 'object') {
      const ps = offer.priceSpecification;
      if (ps.price != null) return ps.price;
      // priceSpecification también puede ser array (rare).
      if (Array.isArray(ps) && ps[0] && ps[0].price != null) return ps[0].price;
    }
    if (offer.lowPrice != null) return offer.lowPrice;
    return null;
  }

  function walkLdJson(node) {
    if (node == null) return null;
    if (Array.isArray(node)) {
      for (const item of node) {
        const r = walkLdJson(item);
        if (r != null) return r;
      }
      return null;
    }
    if (typeof node !== 'object') return null;

    const t = node['@type'];
    const isProduct = t === 'Product' || (Array.isArray(t) && t.includes('Product'));
    if (isProduct && node.offers) {
      const offers = node.offers;
      if (Array.isArray(offers)) {
        // Recorrer todos los offers y devolver el primero con precio válido
        // y stock disponible. Esto evita devolver lowPrice de un offer
        // OutOfStock cuando hay otro offer con stock más arriba en la PDP.
        for (const o of offers) {
          const p = pickOfferPrice(o);
          if (p != null) return p;
        }
      } else if (typeof offers === 'object') {
        const p = pickOfferPrice(offers);
        if (p != null) return p;
      }
    }

    // Walk nested values
    for (const k of Object.keys(node)) {
      const r = walkLdJson(node[k]);
      if (r != null) return r;
    }
    return null;
  }

  // Detecta precios "antes" tachados (line-through) para ignorarlos.
  // Mira el elemento y hasta 3 ancestros: si el style computado, inline style,
  // o cualquier clase contiene line-through / "old"/"previous"/"antes"/"strike"
  // lo skip. También detecta wrappers <s> y <del>.
  function isStrikethroughPrice(el) {
    if (!el || typeof el.closest !== 'function') return false;
    let node = el;
    for (let i = 0; i < 4 && node; i++) {
      const tag = (node.tagName || '').toLowerCase();
      if (tag === 's' || tag === 'del' || tag === 'strike') return true;
      const cls = ((node.className && node.className.baseVal) || node.className || '') + '';
      // Patrones AR (antes, tachado), EN (line-through, strike, crossed), VTEX
      // camelCase (oldPrice, originalPrice, listPrice, regularPrice, wasPrice,
      // productPriceOld), Magento (old-price, special-price-from), Shopify
      // (price--compare-at, price__compare-at), txt-strike, sale-price-from.
      if (/line-through|strike|crossed|old[-_]?price|oldprice|previous[-_]?price|prev[-_]?price|list[-_]?price|listprice|regular[-_]?price|regularprice|was[-_]?price|wasprice|antes|tachad|original[-_]?price|originalprice|compare[-_]?at|compareat|product[-_]?price[-_]?old|priceold|txt[-_]?strike|crossed[-_]?out|crossedout|from[-_]?price|fromprice|reference[-_]?price|referenceprice|previousprice|preciotachado|precio[-_]?anterior|sale[-_]?off|saleoff|msrp|retail[-_]?price|retailprice|before[-_]?price|beforeprice|pretty[-_]?strike|pre[-_]?discount|prediscount|de\s*\$|wasamount|was[-_]?amount|viejo[-_]?precio|viejoprecio|precio[-_]?lista|preciolista|precio[-_]?viejo|precioviejo|crossed[-_]?price|crossedprice|was__|de[-_]?price|deprice|recommended[-_]?retail|recommendedretail|rrp|pvp|catalog[-_]?price|catalogprice|standard[-_]?price|standardprice|undiscounted|non[-_]?sale|nonsale|price__was|price--was|price-was|wasvalue|was[-_]?value|precio[-_]?de[-_]?lista|preciodelista|precio[-_]?full|preciofull|full[-_]?price|fullprice|slashed[-_]?price|slashedprice|striked[-_]?price|strikedprice|prevprice|pvp[-_]?anterior|pvpanterior|tachado[-_]?precio|tachadoprecio|sin[-_]?descuento|sindescuento/i.test(cls)) {
        return true;
      }
      // Atributos data-* específicos de algunos retailers AR (Samsung Hybris,
      // Falabella) que marcan el precio anterior con data-pricetype="WAS" o
      // similar. Más confiable que adivinar por clase.
      try {
        const priceType = node.getAttribute && node.getAttribute('data-pricetype');
        if (priceType && /^was$|^old$|^prev$|^previous$|^list$/i.test(priceType.trim())) {
          return true;
        }
        const priceRole = node.getAttribute && node.getAttribute('data-price-type');
        if (priceRole && /^was$|^old$|^list$|^reference$/i.test(priceRole.trim())) {
          return true;
        }
      } catch (_) { /* ignore */ }
      // Inline style (algunos retailers usan style="text-decoration: line-through")
      try {
        const inline = (node.getAttribute && node.getAttribute('style')) || '';
        if (/line-through/i.test(inline)) return true;
      } catch (_) { /* ignore */ }
      try {
        const cs = node.ownerDocument && node.ownerDocument.defaultView
          ? node.ownerDocument.defaultView.getComputedStyle(node) : null;
        if (cs && (cs.textDecorationLine || cs.textDecoration || '').includes('line-through')) {
          return true;
        }
      } catch (_) { /* ignore */ }
      node = node.parentElement;
    }
    return false;
  }

  // Detecta precios que en realidad son cuotas/intereses ("12 cuotas de $1.234,56",
  // "$1.234,56 x 12 cuotas", "Cuotas sin interés", "promo bancaria"). Mira el
  // texto del elemento y hasta 4 ancestros buscando indicadores típicos AR.
  // Si el texto del propio elemento es "12 cuotas de $1.234" lo descartamos sin
  // mirar ancestros: extraer ese precio como total seria un bug grave (suele ser
  // 1/12 del precio real).
  function isInstallmentPrice(el) {
    if (!el || typeof el.closest !== 'function') return false;
    // 1) Inspección directa del texto del elemento (más rápido y certero).
    let ownText = '';
    try { ownText = (el.textContent || '').trim(); } catch (_) {}
    if (/\bcuotas?\s+(de|sin|fijas|con|mensuales|fijas\s+sin)\b/i.test(ownText)) return true;
    if (/\bx\s+\d{1,2}\s+cuotas?\b/i.test(ownText)) return true;
    if (/\b\d{1,2}\s*x\s*\$/i.test(ownText)) return true; // "12x $1.234"
    if (/\bpor\s+mes\b/i.test(ownText)) return true; // "$1.234 por mes"
    if (/\bal\s+mes\b/i.test(ownText)) return true; // "$1.234 al mes"
    if (/\bmensuales?\b/i.test(ownText) && /\$/.test(ownText)) return true;
    if (/\bhasta\s+(en\s+)?\d{1,2}\s+cuotas?\b/i.test(ownText)) return true;
    // Programa "Cuota Simple" del gobierno argentino (3/6 cuotas fijas con tasa).
    if (/\bcuota\s+simple\b/i.test(ownText)) return true;
    // "Sin interés" usado solo en contexto de cuotas (raramente aparece sin "cuotas"
    // al lado en un nodo de precio principal — si aparece, es indicador de cuotas).
    if (/\bsin\s+inter[eé]s\b/i.test(ownText)) return true;
    // "Financiación" / "financiado en X pagos".
    if (/\bfinanciaci[oó]n\b/i.test(ownText)) return true;
    if (/\b\d{1,2}\s+pagos?\s+(de|sin|fijos)\b/i.test(ownText)) return true;
    // "Precio por mes" / "Precio mensual" explícito.
    if (/\bprecio\s+mensual\b/i.test(ownText)) return true;
    // Ciclo 12: tarjetas específicas AR + "tasa fija" + "X cuotas fijas".
    // Tarjeta Naranja, Tarjeta Shopping, Tarjeta Cencosud, Más Cuotas (BNA)
    // suelen aparecer dentro del bloque de financiación con precio mensual.
    if (/\btarjeta\s+(naranja|shopping|cencosud|carrefour|nativa)\b/i.test(ownText)) return true;
    if (/\bm[aá]s\s+cuotas\b/i.test(ownText)) return true;
    if (/\btasa\s+(fija|cero)\b/i.test(ownText)) return true;
    if (/\b\d{1,2}\s+cuotas\s+fijas?\b/i.test(ownText)) return true;
    // "Plan Z" / "Plan Ahora 12/30" sin la palabra cuota explícita.
    if (/\bplan\s+(ahora|cuotas|z|sueldo)\b/i.test(ownText)) return true;
    // "Promoción bancaria" / "promo banco" textuales.
    if (/\bpromo(?:ci[oó]n)?\s+(banc[oa]ria|banco|tarjeta)\b/i.test(ownText)) return true;
    // Ciclo 14: "Hasta X sin interés" sin la palabra "cuotas" (común en banners
    // promo de Frávega/Garbarino donde el contador implícito son cuotas).
    if (/\bhasta\s+(en\s+)?\d{1,2}\s+sin\s+inter[eé]s\b/i.test(ownText)) return true;
    // Ciclo 14: "X sin interés" textual al lado de un precio (típico cuando el
    // banner publica solo "12 sin interés" como tag al lado del valor).
    if (/^\s*\d{1,2}\s+sin\s+inter[eé]s\s*$/i.test(ownText)) return true;
    // Ciclo 14: precio mensual en formato slash ("/mes", "/mensual", "/cuota").
    if (/\$[\d.,]+\s*\/\s*(mes|mensual|cuota)\b/i.test(ownText)) return true;
    if (/\b\/\s*(mes|mensual)\b/i.test(ownText) && /\$/.test(ownText)) return true;
    // Ciclo 1594: variantes adicionales de cuotas observadas en Hot Sale 2026.
    // "Precio cuota" sin el "de" explícito.
    if (/\bprecio\s+cuota\b/i.test(ownText)) return true;
    // "En X pagos" (variante de "X pagos de").
    if (/\ben\s+\d{1,2}\s+pagos?\b/i.test(ownText)) return true;
    // "Pagá en X" (estilo Mercado Pago).
    if (/\bpag[aá]\s+(en\s+)?\d{1,2}\b/i.test(ownText)) return true;
    // "Precio financiado" (Bgood, Megatone).
    if (/\bprecio\s+financiado\b/i.test(ownText)) return true;
    // "Valor cuota" (algunos retailers usan este label).
    if (/\bvalor\s+cuota\b/i.test(ownText)) return true;
    // 2) Ancestros: buscar contenedores marcados como cuotas/promo/instalment.
    let node = el;
    for (let i = 0; i < 4 && node; i++) {
      const cls = ((node.className && node.className.baseVal) || node.className || '') + '';
      const id = (node.id || '') + '';
      const dataTest = (node.getAttribute && (node.getAttribute('data-testid') || node.getAttribute('data-test-id'))) || '';
      const blob = `${cls} ${id} ${dataTest}`;
      // installment / cuota / finance / monthly / promo bancaria / mensual / Ahora-12 (Argentina) /
      // Cuota Simple, financiacion, pagos-fijos, finance-row, paymentplan.
      // Ciclo 12: tarjeta-naranja, tarjeta-shopping, mas-cuotas, recurring-payment,
      // subscription-price, month-payment, plan-z, plan-sueldo.
      if (/installment|cuota|finance|finan|monthly|per[-_]?month|permonth|promo[-_]?banc|promobanc|mensual|ahora[-_]?12|ahora12|ahora-?\d{1,2}|nowx\d|cuota[-_]?simple|cuotasimple|payment[-_]?plan|paymentplan|pago[-_]?fijo|pagofijo|tarjeta[-_]?naranja|tarjetanaranja|tarjeta[-_]?shopping|tarjetashopping|tarjeta[-_]?cencosud|m[aá]s[-_]?cuotas|mascuotas|recurring[-_]?payment|recurringpayment|subscription[-_]?price|subscriptionprice|subscription[-_]?payment|month[-_]?payment|monthpayment|plan[-_]?(ahora|z|sueldo)|tasa[-_]?fija|tasafija|finance[-_]?row|financerow/i.test(blob)) return true;
      node = node.parentElement;
    }
    return false;
  }

  // Detecta nodos visualmente ocultos. Algunos retailers conservan en el DOM
  // un precio "anterior" con display:none / visibility:hidden / aria-hidden=true
  // que tiene mejor markup que el visible (data-price-amount, content="…"),
  // así que un parser ingenuo lo agarra primero. Filtrarlo evita falsos
  // descuentos. Sólo aplica a elementos no-meta (un meta itemprop="price"
  // legítimamente nunca está visible).
  function isHiddenNode(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'meta' || tag === 'link' || tag === 'script') return false;
    try {
      if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return true;
      // HTML5 `hidden` attribute (algunos retailers la usan para variantes
      // no-seleccionadas que tienen su propio precio renderizado en el DOM).
      if (el.hasAttribute && el.hasAttribute('hidden')) return true;
      const inline = (el.getAttribute && el.getAttribute('style')) || '';
      if (/display\s*:\s*none/i.test(inline)) return true;
      if (/visibility\s*:\s*hidden/i.test(inline)) return true;
      // opacity:0 + pointer-events:none es otro patrón típico.
      if (/opacity\s*:\s*0(?!\.)/i.test(inline) && /pointer-events\s*:\s*none/i.test(inline)) return true;
      const cs = el.ownerDocument && el.ownerDocument.defaultView
        ? el.ownerDocument.defaultView.getComputedStyle(el) : null;
      if (cs) {
        if (cs.display === 'none') return true;
        if (cs.visibility === 'hidden' || cs.visibility === 'collapse') return true;
      }
    } catch (_) { /* ignore */ }
    return false;
  }

  // Detecta nodos que son loading skeletons / shimmer placeholders. Algunos
  // retailers (VTEX, Next.js con React Suspense) renderizan en el DOM un
  // <span class="skeleton"> con texto placeholder ("0,00", "—", "$ 0,00")
  // antes de hidratar el precio real. Si lo agarramos, mostramos el badge
  // sobre un precio inventado que en 1–2 segundos cambiará. Filtrarlo evita
  // falsos positivos en la primera pasada y deja que el observer espere al
  // valor real.
  function isLoadingSkeleton(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'meta' || tag === 'link' || tag === 'script') return false;
    let node = el;
    for (let i = 0; i < 4 && node; i++) {
      const cls = ((node.className && node.className.baseVal) || node.className || '') + '';
      // Patrones cross-framework: Bootstrap (placeholder-glow, placeholder-wave),
      // Tailwind (animate-pulse), Material/MUI (MuiSkeleton), VTEX/Next custom
      // (skeleton-loader, content-loader, shimmer, is-loading, loading-pulse,
      // pulse-loading, react-loading-skeleton).
      if (/\bskeleton\b|skeleton[-_]loader|skeletonloader|\bshimmer\b|loading[-_]?placeholder|loadingplaceholder|placeholder[-_]?glow|placeholderglow|placeholder[-_]?wave|placeholderwave|\bis[-_]?loading\b|isloading|loading[-_]?pulse|loadingpulse|pulse[-_]?loading|pulseloading|\banimate[-_]?pulse\b|animatepulse|content[-_]?loader|contentloader|MuiSkeleton|react[-_]?loading[-_]?skeleton|react-loading-skeleton|sk[-_]?loading|skloading/i.test(cls)) {
        return true;
      }
      // Algunos retailers usan aria-busy="true" en el wrapper mientras hidratan.
      try {
        const ab = node.getAttribute && node.getAttribute('aria-busy');
        if (ab === 'true') return true;
      } catch (_) { /* ignore */ }
      node = node.parentElement;
    }
    return false;
  }

  function extractPrice(siteKey) {
    const info = extractPriceInfo(siteKey);
    if (!info) return null;
    const price = info.price;
    // Ciclo 1619: usar isPriceSane() como única fuente de verdad para validación
    // de rango. Antes este wrapper tenía un cap de 50_000_000 que era más restrictivo
    // que isPriceSane (1e9), causando que precios legítimos de equipos industriales,
    // servidores o electrodomésticos premium se descartaran silenciosamente aquí
    // antes de llegar al caller.
    if (!isPriceSane(price)) return null;
    return price;
  }

  // Detecta nodos cuyo textContent es un placeholder no-numérico ("Consultar
  // precio", "Sin stock", "Agotado", "Producto agotado", "Próximamente"). Algunos
  // retailers AR (Garbarino, Naldo, Cetrogar) renderizan estos strings dentro del
  // mismo selector `.product-price` cuando no hay precio. Sin este filtro, el
  // parser puede agarrar un meta `itemprop="price"` con `content="0"` que ya
  // pasa isPriceSane (rechazado por <1) — pero sirve también para evitar
  // selectores `.price` con texto literal.
  function isPlaceholderPriceText(el) {
    if (!el || !el.textContent) return false;
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'meta') return false; // los metas no tienen textContent visible
    let txt = '';
    try { txt = (el.textContent || '').trim(); } catch (_) { return false; }
    if (!txt) return false;
    // Placeholders típicos: si el nodo NO tiene ningún dígito, claramente no es precio.
    if (!/\d/.test(txt)) {
      if (/consultar|agotad|sin\s+stock|próximamente|proximamente|no\s+disponible|preventa|comuníquese|comuniquese|pre[-_]?venta|stock\s+limitado/i.test(txt)) {
        return true;
      }
    }
    return false;
  }

  // Detecta currency mismatch: si el documento expone og:price:currency u otra
  // pista y NO es ARS (algunos retailers AR listan electrónicos con precio USD
  // y un disclaimer "USD se convierte al cambio"), preferimos no clasificar
  // porque el histórico que tenemos en backend es siempre ARS y el cruce sería
  // engañoso. Devuelve la currency declarada (uppercased) o null.
  function detectDocumentCurrency() {
    try {
      const sels = [
        'meta[property="og:price:currency"]',
        'meta[property="product:price:currency"]',
        'meta[itemprop="priceCurrency"]',
      ];
      for (const sel of sels) {
        const el = document.querySelector(sel);
        const c = el && el.getAttribute && el.getAttribute('content');
        if (c) return String(c).trim().toUpperCase();
      }
      // Fallback: ld+json sin walkear todo.
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const s of scripts) {
        const txt = s.textContent || '';
        const m = txt.match(/"priceCurrency"\s*:\s*"([A-Z]{3})"/);
        if (m) return m[1];
      }
    } catch (_) { /* ignore */ }
    return null;
  }

  // Sanity check: descartar precios obviamente espurios. Hot Sale AR rara vez
  // tiene productos por menos de $100 (excepto centavos sueltos de error de
  // parsing) ni más de $1.000.000.000 (son outliers de typos en JSON-LD).
  // El piso bajo es 1 porque schema.org permite "0.00" para "ver precio en
  // el carrito" — si quedó en 0 no es informativo. El techo alto evita que
  // un parse de "12345678901" como cents (123.456.789,01) pase como real.
  function isPriceSane(n) {
    if (!Number.isFinite(n)) return false;
    if (n < 1) return false;
    if (n > 1e9) return false;
    return true;
  }

  // Ciclo 14: detección de currency en el nodo de precio mismo. Algunos
  // retailers AR (LG, Sony, marcas premium) listan electrónicos importados
  // con su precio en USD aunque el documento declare ARS en og:price:currency
  // (porque el meta refleja el precio "general" pero el visible en la PDP
  // es la conversión USD). Si el textContent del nodo seleccionado contiene
  // "U$S", "USD", "US$", "U$D" como prefijo/sufijo del número, es señal de
  // que el valor no es ARS aunque el meta diga lo contrario. Devolver true
  // hace que extractPriceInfo descarte ese nodo y siga con el siguiente.
  function isPriceTextUSD(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    // Los meta tags no tienen textContent visible: confiamos en el atributo.
    if (tag === 'meta') return false;
    let txt = '';
    try { txt = (el.textContent || '').trim(); } catch (_) { return false; }
    if (!txt) return false;
    // Patrones AR para "Dólar estadounidense": U$S, U$D, US$, USD (palabra suelta).
    // No matcheamos el símbolo "$" solo (es tanto USD como ARS en AR).
    if (/\bU\$\s?[SD]\b/i.test(txt)) return true;
    if (/\bUS\s?\$/i.test(txt)) return true;
    if (/\bUSD\b/.test(txt)) return true;
    // "Dólares" / "dólares" textuales.
    if (/\bd[oó]lar(es)?\b/i.test(txt)) return true;
    return false;
  }

  // Para Mercado Libre: el `.andes-money-amount__fraction` contiene solo la
  // parte entera ("1.234"). Para precios con cents no triviales (raro en ARS
  // pero ocurre), preferimos leer el ancestro `.andes-money-amount` que tiene
  // el precio completo ("$ 1.234,56") en su textContent + un atributo
  // `aria-label="Pesos 1234 con 56 centavos"`.
  function readMlPrice(el) {
    if (!el) return null;
    // Si el elemento ya es .andes-money-amount, usar su aria-label como fuente
    // confiable (siempre formato US-ish: "Pesos 1234 con 56 centavos").
    const moneyAmount = (el.classList && el.classList.contains('andes-money-amount'))
      ? el
      : (typeof el.closest === 'function' ? el.closest('.andes-money-amount') : null);
    if (moneyAmount) {
      const aria = moneyAmount.getAttribute('aria-label') || '';
      // "Pesos 1234 con 56 centavos" → 1234.56
      const m = aria.match(/(\d[\d\.,]*)\s*(?:con\s+(\d{1,2})\s*centavos?)?/i);
      if (m) {
        const ent = m[1] ? m[1].replace(/[.,]/g, '') : '';
        const cents = m[2] || '';
        if (ent) {
          const composed = cents ? `${ent}.${cents.padStart(2, '0')}` : ent;
          const n = Number(composed);
          if (Number.isFinite(n) && n > 0) return n;
        }
      }
      // Sin aria-label: combinar fraction + cents si existen.
      const frac = moneyAmount.querySelector('.andes-money-amount__fraction');
      const cents = moneyAmount.querySelector('.andes-money-amount__cents');
      if (frac) {
        const ent = (frac.textContent || '').replace(/[^\d]/g, '');
        const c = cents ? (cents.textContent || '').replace(/[^\d]/g, '') : '';
        if (ent) {
          const composed = c ? `${ent}.${c.padStart(2, '0')}` : ent;
          const n = Number(composed);
          if (Number.isFinite(n) && n > 0) return n;
        }
      }
    }
    return null;
  }

  // Issue #2: parser por retailer devuelve {price, currency, retailer}.
  function extractPriceInfo(siteKey) {
    const retailer = siteKey || detectSite(location.hostname) || null;
    // Currency mismatch hard-stop: si el documento declara una moneda distinta
    // de ARS (algunos retailers AR muestran USD para electrónicos importados),
    // no clasificamos — el histórico del backend está en ARS y el cruce daría
    // falsos descuentos/inflados. Una currency null o ARS sigue el camino normal.
    // Permitimos también currencies vacías o "$" mal codificadas.
    try {
      const declared = detectDocumentCurrency();
      if (declared && declared !== 'ARS' && /^[A-Z]{3}$/.test(declared)) {
        log.debug(retailer, 'document currency mismatch, skipping', declared);
        return null;
      }
    } catch (_) { /* fail open: si la detección falla, intentar */ }
    const siteSelectors = (retailer && PRICE_SELECTORS[retailer]) ? PRICE_SELECTORS[retailer] : [];
    const selectors = [...siteSelectors, ...GENERIC_PRICE_SELECTORS];

    for (const sel of selectors) {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        // Ciclo 1619: loggear selectores inválidos en modo debug para ayudar a
        // detectar regresiones en retailers.js durante el desarrollo. En producción
        // el log.debug es no-op salvo que el usuario active precio_real_debug.
        log.debug(retailer, 'invalid selector skipped', sel, e && e.message);
        continue;
      }
      for (const el of nodes) {
        // Saltar nodos ocultos (display:none / visibility:hidden / aria-hidden).
        // Excepto meta tags, que siempre son "ocultos" pero válidos.
        if (isHiddenNode(el)) continue;
        // Saltar loading skeletons / shimmer placeholders (todavía hidratando).
        if (isLoadingSkeleton(el)) continue;
        // Saltar precios visiblemente tachados (precio anterior, "antes").
        if (isStrikethroughPrice(el)) continue;
        // Saltar precios que en realidad son cuotas mensuales o promos
        // bancarias (el ancestro o el propio texto lo declara).
        if (isInstallmentPrice(el)) continue;
        // Saltar placeholders textuales tipo "Consultar precio" / "Sin stock".
        if (isPlaceholderPriceText(el)) continue;
        // Ciclo 14: defensa adicional contra precios USD visibles aunque el
        // documento declare ARS. Si el textContent del nodo contiene "U$S",
        // "USD", "US$", saltamos — el histórico backend está siempre en ARS.
        if (isPriceTextUSD(el)) continue;

        // Camino especializado para Mercado Libre: reconstruir desde el
        // contenedor `.andes-money-amount` para no perder los cents.
        if (retailer === 'mercadolibre') {
          const ml = readMlPrice(el);
          if (isPriceSane(ml)) {
            return { price: ml, currency: 'ARS', retailer };
          }
        }

        const { raw, fromAttribute } = readPriceFromElement(el);
        const n = normalizePrice(raw, { forceUSDecimal: fromAttribute });
        if (isPriceSane(n)) {
          return { price: n, currency: 'ARS', retailer };
        }
      }
    }

    const ld = tryLdJsonPrice();
    if (ld != null && isPriceSane(ld)) {
      return { price: ld, currency: 'ARS', retailer };
    }

    return null;
  }

  function canonicalUrl(href) {
    try {
      const u = new URL(href);
      return u.protocol + '//' + u.host.toLowerCase() + u.pathname;
    } catch (e) {
      return href;
    }
  }

  // productKey: identifica un producto + variante. La URL canónica solita no
  // alcanza porque retailers como Mercado Libre, Frávega, Falabella mantienen
  // la URL fija al cambiar talle/color y solo cambian un query param o el
  // estado del DOM. Combinamos canonicalUrl con SKU/variantId/color cuando el
  // DOM los expone (data-* o JSON-LD).
  function productKey(href) {
    const base = canonicalUrl(href || location.href);

    // Amazon: normalizar a /dp/ASIN para que URLs con /ref=... distintos apunten
    // al mismo historial en el backend. Si el usuario ya eligió una variante,
    // el DOM actualiza #landingAsin o data-csa-c-asin con el ASIN de la variante.
    const siteKey = detectSite(location.hostname);
    if (siteKey === 'amazon') {
      const urlStr = href || location.href;
      const m = urlStr.match(/\/(dp|gp\/product)\/([A-Z0-9]{10})/i);
      if (m) {
        let asin = m[2].toUpperCase();
        try {
          const landingEl = document.getElementById('landingAsin');
          if (landingEl && landingEl.value && /^[A-Z0-9]{10}$/i.test(landingEl.value)) {
            asin = landingEl.value.toUpperCase();
          } else {
            const csaEl = document.querySelector('[data-csa-c-asin]');
            const csaAsin = csaEl && csaEl.getAttribute('data-csa-c-asin');
            if (csaAsin && /^[A-Z0-9]{10}$/i.test(csaAsin)) asin = csaAsin.toUpperCase();
          }
        } catch (_) {}
        return 'https://www.amazon.com.ar/dp/' + asin;
      }
    }

    let variant = '';
    try {
      // 1) Variante en el query (ML usa ?variation=...)
      const u = new URL(href || location.href);
      // Ciclo 1604: skuId = VTEX (garbarino, jumbo, etc.), colorId = Falabella/Sodimac,
      // itemId = VTEX legacy. Estos params cambian con la variante sin cambiar el pathname.
      const variationParams = ['variation', 'sku', 'skuId', 'pid', 'productId', 'itemId', 'variant', 'colorId'];
      for (const k of variationParams) {
        const v = u.searchParams.get(k);
        if (v) { variant += `|${k}=${v}`; }
      }
      // 2) DOM: el elemento [data-sku] / [data-product-id] suele actualizarse
      //    al cambiar variante.
      const skuEl = document.querySelector('[data-sku],[data-product-sku],[data-product-id],[data-variant-id]');
      if (skuEl) {
        const sku = skuEl.getAttribute('data-sku')
          || skuEl.getAttribute('data-product-sku')
          || skuEl.getAttribute('data-product-id')
          || skuEl.getAttribute('data-variant-id');
        if (sku) variant += `|sku=${sku}`;
      }
      // 3) Variante seleccionada en el atributo aria-pressed/selected.
      const selectedSwatch = document.querySelector(
        '[role="radio"][aria-checked="true"][data-value],' +
        '[aria-pressed="true"][data-value],' +
        '[aria-selected="true"][data-value],' +
        '.is-selected[data-value],' +
        '.selected[data-value]'
      );
      if (selectedSwatch) {
        const v = selectedSwatch.getAttribute('data-value');
        if (v) variant += `|swatch=${v}`;
      }
    } catch (_) { /* ignore */ }
    return base + variant;
  }

  function fallbackClassify(current, history) {
    const DAY = 86400;
    const now = Math.floor(Date.now() / 1000);
    if (!current || !Array.isArray(history) || history.length < 5) {
      return { kind: 'unknown', pct: 0, label: 'Precio Real: sin datos', sub: 'Histórico insuficiente' };
    }
    const last7 = history.filter(h => now - h.scraped_at <= 7 * DAY).map(h => h.price);
    const prev23 = history.filter(h => {
      const age = now - h.scraped_at;
      return age > 7 * DAY && age <= 30 * DAY;
    }).map(h => h.price);
    if (prev23.length === 0) {
      return { kind: 'unknown', pct: 0, label: 'Precio Real: sin baseline', sub: '' };
    }
    const sorted = [...prev23].sort((a, b) => a - b);
    const baseline = sorted[Math.floor(sorted.length / 2)];
    const max7 = last7.length ? Math.max(...last7) : current;
    if (max7 >= baseline * 1.10 && current >= baseline * 0.95) {
      const pct = Math.round(((max7 - baseline) / baseline) * 100);
      return { kind: 'inflated', pct, label: 'Precio Real: ✗ INFLADO', sub: `Subió ${pct}% la semana pasada` };
    }
    if (current <= baseline * 0.95) {
      const pct = Math.round(((baseline - current) / baseline) * 100);
      return { kind: 'real', pct, label: 'Precio Real: ✓ DESCUENTO REAL', sub: `-${pct}% vs. histórico` };
    }
    return { kind: 'neutral', pct: 0, label: 'Precio Real: sin descuento', sub: 'Estable vs. histórico' };
  }

  function formatDiscount(pct) {
    // pct is a number (e.g., 12.3) or null. Returns "+12.3%" / "-4.0%" / "—".
    if (pct === null || pct === undefined || Number.isNaN(pct)) return "—";
    const sign = pct > 0 ? "+" : "";  // negative numbers already have "-"
    return `${sign}${pct.toFixed(1)}%`;
  }

  // ── Detección "página de producto" reforzada ──────────────────────────────
  // isProductPageStrict() devuelve true solo cuando hay señales fuertes:
  // schema.org Product, og:type=product, JSON-LD con Product, o microdata con
  // itemtype Product. Se complementa con `urlLooksLikeListing()` que marca como
  // false hits típicos de categoría/listado.
  function urlLooksLikeListing(siteKey, pathname) {
    const p = (pathname || location.pathname || '').toLowerCase();
    // Patrones genéricos de listado/categoría/búsqueda.
    // NOTA: hot-sale/cyber/black-friday NO están aquí — son nombres de campaña
    // que los retailers usan como prefijo de PATH incluso en PDPs individuales
    // (ej. fravega.com/hot-sale/tv-samsung-55/p-ABC123/). Incluirlos bloqueaba
    // el badge en las páginas de producto durante los eventos más relevantes.
    if (/^\/(categor[ií]a|categorias|seccion|secciones|listado|listing|search|busqueda|buscar|ofertas|outlet|marca|marcas|departamento|colecci[oó]n|colecciones)(\/|$)/i.test(p)) {
      return true;
    }
    // Ciclo 1620: cart, checkout, account y login nunca son PDPs. Sin este guard,
    // un /cart con producto único (Shopify quick-add) podía disparar el badge.
    if (/^\/(cart|checkout|checkouts|account|accounts|login|register|mi-cuenta|mi-perfil|orders?)(\/|$)/i.test(p)) {
      return true;
    }
    // ML: /listado, /listings, /jm/search
    if (siteKey === 'mercadolibre') {
      if (p.startsWith('/listado') || p.includes('/jm/search') || p.startsWith('/c/')) return true;
    }
    // VTEX (jumbo, disco, dia, easy, hendel): URLs de search típicamente terminan en `?map=...&_q=`.
    if (location.search && /[?&]map=/.test(location.search) && !/[?&]sku=/.test(location.search)) {
      return true;
    }
    // Amazon AR: search, browse, deals y tiendas de marca son listas, nunca PDPs.
    if (siteKey === 'amazon') {
      if (/^\/s(\?|$)/.test(p) || /^\/b(\?|$)/.test(p)) return true;
      if (p.startsWith('/gp/browse') || p.startsWith('/gp/goldbox') || p.startsWith('/gp/deal')) return true;
      if (p.startsWith('/deals/') || p.startsWith('/stores/')) return true;
    }
    // WooCommerce (Drean, HiperTehno, EXO): categorías y etiquetas son listados.
    if (/^\/(product-category|product-tag)(\/|$)/i.test(p)) return true;
    // PrestaShop (Todomodo, Alphatec): categorías tienen solo dígitos como prefijo de segmento.
    if ((siteKey === 'todomodo' || siteKey === 'alphatec') && /^\/\d+[-\/]/.test(p) && !/\/[a-z0-9-]+-\d+\.html/.test(p)) return true;
    // Paginación genérica: ningún PDP es paginated.
    if (/\/page\/\d+(\/|$)/.test(p)) return true;
    // Slugs con guión: /categoria-electrodomesticos, /coleccion-verano, etc.
    if (/^\/(categor[ií]a-|colecci[oó]n-)/i.test(p)) return true;
    // Lenovo AR: /ar/laptops/, /ar/tablets/ son categorías; solo /ar/p/ o /ar/…/product es PDP.
    if (siteKey === 'lenovo') {
      if (/^\/ar\/(laptops?|tablets?|desktops?|workstations?|servers?|accessories|bundles?)(\/|$)/i.test(p)) return true;
    }
    // Shopify (TCL AR y otros): /collections/<handle> son listados de categoría;
    // /products/<handle> son PDPs. Un path que empieza en /collections/ y no
    // tiene /products/ anidado es siempre un listado.
    if (/^\/collections\/[^/]+(\/|$)/.test(p) && !/\/products\//.test(p)) return true;
    // Asus Store AR (store.asus.com/ar/): /ar/shop/, /ar/Accessories/, /ar/search/
    // son listados; /ar/Shop/ProductDetail/ y /ar/product/ son PDPs.
    if (siteKey === 'asus') {
      if (/^\/ar\/(shop|search|brand|accessories|gaming-deals?|store\/promotion)(\/|$)/i.test(p) && !/productdetail/i.test(p)) return true;
    }
    return false;
  }

  function hasProductMicrodata() {
    try {
      if (document.querySelector('[itemtype*="schema.org/Product" i]')) return true;
      if (document.querySelector('[itemprop="price"]')) return true;
      const og = document.querySelector('meta[property="og:type"]');
      if (og && /product/i.test(og.getAttribute('content') || '')) return true;
      const ld = document.querySelectorAll('script[type="application/ld+json"]');
      for (const s of ld) {
        const txt = s.textContent || '';
        if (/"@type"\s*:\s*"?Product"?/i.test(txt) || txt.includes('"Product"')) return true;
      }
    } catch (_) { /* ignore */ }
    return false;
  }

  function isProductPageStrict(siteKey) {
    try {
      if (urlLooksLikeListing(siteKey)) {
        // Override: si la página tiene microdata de producto (JSON-LD Product,
        // og:type=product, itemprop=price) confiamos en eso por sobre la URL.
        // Cubre retailers que usan rutas de categoría como contenedor del PDP
        // (ej. /buscar?q=... con un producto único pre-filtrado, o /ofertas/prod).
        if (hasProductMicrodata()) return true;
        return false;
      }
      if (siteKey === 'mercadolibre') {
        if (location.hostname.startsWith('articulo.')) return true;
        if (/\/p\//.test(location.pathname)) return true;
        if (/MLA-?\d+/i.test(location.pathname)) return true;
        return false;
      }
      // Amazon: producto = /dp/ASIN o /gp/product/ASIN. Todo lo demás es listado/home.
      if (siteKey === 'amazon') {
        return /\/(dp|gp\/product)\/[A-Z0-9]{10}/i.test(location.pathname);
      }
      // WooCommerce (Drean, HiperTehno, EXO, Mac Center, Full): single-product tiene body.single-product o /product/ en la ruta.
      if (siteKey === 'drean' || siteKey === 'hipertehno' || siteKey === 'exo' || siteKey === 'maccenter' || siteKey === 'full') {
        try {
          if (document.body && document.body.classList.contains('single-product')) return true;
        } catch (_) {}
        if (/\/product\//.test(location.pathname)) return true;
        // Caer al microdata check: WooCommerce siempre emite JSON-LD de Product.
      }
      // Asus Store AR: PDPs tienen /ProductDetail/ o /product/ en la ruta, o JSON-LD Product.
      if (siteKey === 'asus') {
        if (/\/(ProductDetail|product|item)\//.test(location.pathname)) return true;
        // Caer al microdata check: Asus emite JSON-LD de Product en sus PDPs.
      }
      // Magento 2 (Cetrogar, Rodo, Noblex, Venex, BGood, HP Tienda, Pycca, Acer, TGC, StartTech, PC Factory):
      // body tiene la clase catalog-product-view en todas las PDPs de Magento 2.
      // Es el identificador más confiable: Magento lo agrega server-side antes de
      // que JS hidrate, por lo que está disponible en document_idle.
      // Ciclo 1607: TGC AR también usa Magento 2.
      // Ciclo 1608: StartTech AR también usa Magento 2.
      // Ciclo 1609: PC Factory AR también usa Magento 2.
      // Ciclo 1614: InStore AR también usa Magento 2 (audio/video hifi).
      // Ciclo 1618: GrupoDIN AR y Megatronics AR también usan Magento 2.
      if (siteKey === 'cetrogar' || siteKey === 'rodo' || siteKey === 'noblex' ||
          siteKey === 'venex' || siteKey === 'bgood' || siteKey === 'hptienda' || siteKey === 'pycca' ||
          siteKey === 'microcenter' || siteKey === 'acer' || siteKey === 'tgc' || siteKey === 'starttech' ||
          siteKey === 'pcfactory' || siteKey === 'nexstore' || siteKey === 'netizar' || siteKey === 'centurytech' ||
          siteKey === 'instore' || siteKey === 'grupodin' || siteKey === 'megatronics') {
        try {
          if (document.body && document.body.classList.contains('catalog-product-view')) return true;
        } catch (_) {}
        // Magento 2 emite JSON-LD de Product: caer al microdata check.
      }
      // Shopify (TCL AR, iPoint AR, Musimundo, Compumundo, Coolbox AR, Dexter AR, FullH4rd AR, Golden Shop AR):
      // PDPs tienen /products/ en la ruta y/o body.template-product.
      // Ciclo 1606: Coolbox AR también usa Shopify.
      // Ciclo 1607: Dexter AR también usa Shopify.
      // Ciclo 1608: FullH4rd AR también usa Shopify (gaming/periféricos).
      // Ciclo 1609: Golden Shop AR también usa Shopify (accesorios/electrónica).
      // Ciclo 1614: Bit AR también usa Shopify (gaming/hardware).
      // Ciclo 1615: I-Gaming Store AR también usa Shopify (gaming/hardware).
      // Ciclo 1616: Klibr AR y Lazer AR también usan Shopify (gaming periféricos/sillas).
      // Ciclo 1617: GearZone AR también usa Shopify (gaming bundles/periféricos).
      // Ciclo 1618: Mac Station AR, Megatrix AR y Pixelstore AR también usan Shopify.
      if (siteKey === 'tcl' || siteKey === 'ipoint' || siteKey === 'musimundo' || siteKey === 'compumundo' ||
          siteKey === 'coolbox' || siteKey === 'dexter' || siteKey === 'fullh4rd' || siteKey === 'goldenshop' ||
          siteKey === 'bit' || siteKey === 'ithink' || siteKey === 'igaming' || siteKey === 'klibr' ||
          siteKey === 'lazer' || siteKey === 'gearzone' || siteKey === 'macstation' || siteKey === 'megatrix' ||
          siteKey === 'pixelstore') {
        if (/\/products\//.test(location.pathname)) return true;
        try {
          if (document.body && document.body.classList.contains('template-product')) return true;
        } catch (_) {}
        // Shopify emite JSON-LD de Product en PDPs: caer al microdata check.
      }
      // WooCommerce (Olimpo AR, PC House AR, Zetta AR, Soluciones AR): single-product tiene body.single-product o /product/ en la ruta.
      // Ciclo 1606: Olimpo AR usa WooCommerce.
      // Ciclo 1608: PC House AR también usa WooCommerce (hardware).
      // Ciclo 1609: Soluciones AR también usa WooCommerce (informática/gaming).
      // Ciclo 1610: Zetta AR también usa WooCommerce (electrónica/computing).
      // Ciclo 1614: Digital Haus AR (electrónica), Staples AR (oficina) y Gotta AR (gaming) también usan WooCommerce.
      // Ciclo 1615: Powerplanet AR y Megastore AR también usan WooCommerce.
      // Ciclo 1616: PcArg AR también usa WooCommerce (componentes/hardware/gaming).
      // Ciclo 1617: Binario AR y CompuPC AR también usan WooCommerce (componentes/gaming).
      // Ciclo 1618: Carsa AR (electrodomésticos regional) y Autronic AR también usan WooCommerce.
      if (siteKey === 'olimpo' || siteKey === 'pchouse' || siteKey === 'zetta' || siteKey === 'soluciones' ||
          siteKey === 'cablehogar' || siteKey === 'digitalhaus' || siteKey === 'staples' || siteKey === 'gotta' ||
          siteKey === 'powerplanet' || siteKey === 'megastore' || siteKey === 'pcarg' ||
          siteKey === 'binario' || siteKey === 'compupc' || siteKey === 'carsa' || siteKey === 'autronic') {
        try {
          if (document.body && document.body.classList.contains('single-product')) return true;
        } catch (_) {}
        if (/\/product\//.test(location.pathname)) return true;
        // WooCommerce emite JSON-LD de Product: caer al microdata check.
      }
      // Shopify (Geek Store AR): PDPs tienen /products/ en la ruta y/o body.template-product.
      // Ciclo 1610: Geek Store AR usa Shopify (gaming/periféricos).
      if (siteKey === 'geekstore') {
        if (/\/products\//.test(location.pathname)) return true;
        try {
          if (document.body && document.body.classList.contains('template-product')) return true;
        } catch (_) {}
        // Shopify emite JSON-LD de Product en PDPs: caer al microdata check.
      }
      // Magento 2 (Computodo AR): body tiene clase catalog-product-view en todas las PDPs.
      // Ciclo 1610: Computodo AR usa Magento 2 (hardware/PC building).
      if (siteKey === 'computodo') {
        try {
          if (document.body && document.body.classList.contains('catalog-product-view')) return true;
        } catch (_) {}
        // Magento 2 emite JSON-LD de Product: caer al microdata check.
      }
      // PrestaShop (Arredondo AR): PDPs tienen body.product-type-simple o /producto/ en la ruta.
      // Ciclo 1612: Arredondo AR usa PrestaShop (electrónica/electrodomésticos).
      if (siteKey === 'arredondo') {
        try {
          if (document.body && document.body.classList.contains('product-type-simple')) return true;
          if (document.body && document.body.classList.contains('woocommerce-page')) return true;
        } catch (_) {}
        if (/\/producto\//.test(location.pathname) || /\/product\//.test(location.pathname)) return true;
        // PrestaShop emite JSON-LD de Product: caer al microdata check.
      }
      // Ciclo 1604: VTEX IO — PDPs siempre tienen pathname terminando en /p (antes del
      // query string). También: skuId en query = variante de un PDP (siempre producto).
      // Cubre: garbarino, jumbo, disco, easy, carrefour, changomas, hisense, philco, newsan.
      // No incluimos fravega aquí porque usa VTEX Classic con URLs distintas.
      // Ciclo 1607: maxiconsumo también usa VTEX IO.
      // Ciclo 1609: maxihogar también usa VTEX IO (electrodomésticos).
      // Ciclo 1618: coppel también usa VTEX IO (línea blanca/electrónica).
      const VTEX_IO_SITES = ['garbarino', 'jumbo', 'disco', 'easy', 'carrefour', 'changomas',
                             'hisense', 'philco', 'newsan', 'maxiconsumo', 'maxihogar', 'coppel'];
      if (VTEX_IO_SITES.indexOf(siteKey) !== -1) {
        if (/\/p$/.test(location.pathname)) return true;
        try {
          if (new URL(location.href).searchParams.has('skuId')) return true;
        } catch (_) {}
        // VTEX IO emite JSON-LD de Product: caer al microdata check.
      }
      // PrestaShop (Todomodo, Alphatec): body.page-product o body.product-page
      // está presente en todas las PDPs de PrestaShop por defecto.
      if (siteKey === 'todomodo' || siteKey === 'alphatec') {
        try {
          if (document.body && (
            document.body.classList.contains('page-product') ||
            document.body.classList.contains('product-page')
          )) return true;
        } catch (_) {}
        // PrestaShop emite JSON-LD de Product: caer al microdata check.
      }
      // Lenovo AR: PDP tiene /p/ o el pathname no es una categoría genérica.
      if (siteKey === 'lenovo') {
        if (/\/p\//.test(location.pathname)) return true;
        // Lenovo emite JSON-LD de Product en todas sus PDPs.
      }
      if (hasProductMicrodata()) return true;
      // Fallback: existe nodo de precio típico en el viewport.
      if (document.querySelector('.price, .product-price, [data-testid*="price" i], [data-test-id*="price" i]')) {
        // …pero también hay un contenedor "producto" (form add-to-cart, gallery, sku).
        const productSignals = document.querySelector(
          '[itemtype*="Product" i], [data-testid*="product" i], [data-test-id*="product" i], ' +
          'button[aria-label*="agregar" i], button[aria-label*="add to cart" i], ' +
          '[id*="addToCart" i], form[action*="cart" i]'
        );
        if (productSignals) return true;
      }
    } catch (_) { return true; /* ante duda, intentar */ }
    return false;
  }

  ns.SUPPORTED_SITES = SUPPORTED_SITES;
  ns.detectSite = detectSite;
  ns.normalizePrice = normalizePrice;
  ns.PRICE_SELECTORS = PRICE_SELECTORS;
  ns.extractPrice = extractPrice;
  ns.extractPriceInfo = extractPriceInfo;
  ns.canonicalUrl = canonicalUrl;
  ns.productKey = productKey;
  ns.fallbackClassify = fallbackClassify;
  ns.formatDiscount = formatDiscount;
  ns.urlLooksLikeListing = urlLooksLikeListing;
  ns.hasProductMicrodata = hasProductMicrodata;
  ns.isProductPageStrict = isProductPageStrict;
  ns.isStrikethroughPrice = isStrikethroughPrice;
  ns.isInstallmentPrice = isInstallmentPrice;
  ns.isHiddenNode = isHiddenNode;
  ns.isLoadingSkeleton = isLoadingSkeleton;
  ns.isPriceSane = isPriceSane;
  ns.isPlaceholderPriceText = isPlaceholderPriceText;
  ns.isPriceTextUSD = isPriceTextUSD;
  ns.detectDocumentCurrency = detectDocumentCurrency;
  ns.log = log;
  ns.DEBUG = DEBUG;
})();
